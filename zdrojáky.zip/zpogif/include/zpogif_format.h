#ifndef ZPOGIF_FORMAT_H
#define ZPOGIF_FORMAT_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
	ZPOGIF_RGB,
	ZPOGIF_GRAYSCALE
} zpogif_format;

#ifdef __cplusplus
}
#endif

#endif
