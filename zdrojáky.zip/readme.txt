Projekt je rozdělen do tří částí:
* knihovna libzpogif - nahrávání a ukládání GIF souborů
* knihovna libzpopcx - nahrávání a ukládání PCX souborů
* složka examples - příkladové aplikace použití knihoven

Všechny složky obsahují Makefile pro sestavení dané části.
